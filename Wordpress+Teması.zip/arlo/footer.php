<!-- CONTACT & FOOTER -->
<div class="arlo_tm_section" id="contact">
	<div class="arlo_tm_footer_contact_wrapper_all">
		<div class="arlo_tm_footer_wrap">
			<div class="container">
				<p>&copy; Copyright 2019. All Rights are Reserved.</p>
			</div>
		</div>
	</div>
</div>

<!-- /CONTACT & FOOTER -->
	

			
			</div>
		</div>
		<!-- /RIGHTPART -->

		<a class="arlo_tm_totop" href="#"></a> 
		
	</div>
</div>
<!-- / WRAPPER ALL -->



<?php wp_footer(); ?>
</body>
</html>