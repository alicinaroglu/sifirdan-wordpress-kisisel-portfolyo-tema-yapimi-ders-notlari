<?php get_header();?>
<h1>Sayfa Bulunamadı</h1>
<?php get_footer(); ?>