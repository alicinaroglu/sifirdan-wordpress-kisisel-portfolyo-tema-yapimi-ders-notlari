<?php /*Template Name: Ana Sayfa */ get_header();?>
<?php //echo "<pre>"; echo print_r($giris_gorseli); echo "</pre>";?>


				
				<?php $giris_bolumunu_goster = get_field('giris_bolumunu_goster');?>
				<?php if($giris_bolumunu_goster):?>
				
				<div class="arlo_tm_section" id="giris">
					<div class="arlo_tm_hero_header_wrap">
						<div class="arlo_tm_universal_box_wrap">
							<div class="bg_wrap">
								<div class="overlay_image hero jarallax" data-speed="0.1"></div>
								<div class="overlay_color hero"></div>
							</div>
							<div class="content hero">
								<div class="inner_content">
									
									<?php $giris_gorseli = get_field('giris_gorseli');?>
									
									<?php if($giris_gorseli):?>								
									<div class="image_wrap">
										<img src="<?php echo $giris_gorseli['url'];?>" alt="hero" />
									</div>
									<?php endif;?>
									
									<?php $giris_yazisi = get_field('giris_yazisi');?>
									<?php if($giris_yazisi):?>
									<div class="name_holder">
										<h3><?php echo $giris_yazisi;?></h3>
									</div>
									<?php endif;?>
									
									
									<?php $giris_yazisi_unvanlar = get_field('giris_yazisi_unvanlar');?>
									<?php if($giris_yazisi_unvanlar):?>
									<div class="text_typing">
										<p><?php echo $giris_yazisi_unvanlar;?></p>
									</div>
									<?php endif;?>
								</div>
							</div>
							<div class="arlo_tm_arrow_wrap bounce anchor">
								<a href="#about"><i class="xcon-angle-double-down"></i></a>
							</div>
						</div>
					</div>
				</div>
				
				<?php endif;?>
				
				
				<?php $hakkimda_bolumunu_goster = get_field('hakkimda_bolumunu_goster');?>
				<?php if($hakkimda_bolumunu_goster):?>
				<!-- ABOUT -->
				<div class="arlo_tm_section relative" id="hakkimda">
					<div class="arlo_tm_about_wrapper_all">
						<div class="container">
							
							<div class="arlo_tm_title_holder">
								<h3><?php the_field('hakkimda_bolum_basligi');?></h3>
								<span><?php the_field('hakkimda_bolum_basligi_yazi');?></span>
							</div>
							
							<div class="arlo_tm_about_wrap">
								<div class="author_wrap">
									
									<div class="leftbox">
										
										<?php $hakkimda_gorseli = get_field('hakkimda_gorseli');?>
										<?php if($hakkimda_gorseli):?>
										<div class="about_image_wrap parallax" data-relative-input="true">
											<div class="image layer" data-depth="0.1">
											<img src="<?php echo get_template_directory_uri();?>/inc/img/about/550x640.jpg" alt="550x640" />
												<div class="inner" data-img-url="<?php echo $hakkimda_gorseli['url'];?>"></div>
											</div>
											<div class="border layer" data-depth="0.2">
											<img src="<?php echo get_template_directory_uri();?>/inc/img/about/550x640.jpg" alt="550x640" />
												<div class="inner"></div>
											</div>
										</div>
										<?php endif;?>
									</div>
									
									<div class="rightbox">
										<div class="arlo_tm_mini_title_holder">
											<?php $hakkimda_yazi_basligi = get_field('hakkimda_yazi_basligi');?>
											<?php if($hakkimda_yazi_basligi):?>
											<h4><?php echo $hakkimda_yazi_basligi;?></h4>
											<?php endif;?>
										</div>
										<div class="definition">
											<?php the_field('hakkimda_yazi')?>
											
										</div>
										
										<?php $hakkimda_detayli_bilgiler = get_field('hakkimda_detayli_bilgiler');?>
										<?php if($hakkimda_detayli_bilgiler):?>
										<div class="about_short_contact_wrap">
										<?php echo $hakkimda_detayli_bilgiler;?>	
										</div>
										<?php endif;?>
										
										
										<div class="buttons_wrap">
											<ul>
												
												<?php $hakkimda_buton_1_yazisi = get_field('hakkimda_buton_1_yazisi');?>
												<?php if($hakkimda_buton_1_yazisi):?>
												<li>
													<a href="<?php the_field('hakkimda_buton_1_linki');?>"><span><?php echo $hakkimda_buton_1_yazisi;?></span></a>
												</li>
												<?php endif;?>
												
												<?php $hakkimda_buton_2_yazisi = get_field('hakkimda_buton_2_yazisi');?>
												<?php if($hakkimda_buton_2_yazisi):?>
												
												<li class="anchor">
													<a href="<?php the_field('hakkimda_buton_2_linki');?>"><span><?php echo $hakkimda_buton_2_yazisi;?></span></a>
												</li>
												<?php endif;?>
												
											</ul>
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /ABOUT -->
				<?php endif;?>
				
				
				
				<?php $yeteneklerim_bolumunu_goster = get_field('yeteneklerim_bolumunu_goster');?>
				<?php if($yeteneklerim_bolumunu_goster):?>
				<!-- SKILLS -->
				<div class="arlo_tm_section">
					<div class="arlo_tm_skills_wrap">
						<div class="container">
							<div class="inner_wrap">
								<div class="leftbox">
									<div class="arlo_tm_mini_title_holder">
										<h4><?php the_field('yeteneklerim_baslik');?></h4>
									</div>
									<?php the_field('yeteneklerim_yazi');?>
									
								</div>
								
								<div class="rightbox">
									<div class="progress_bar_wrap_total">
										<div class="arlo_tm_progress_wrap" data-size="small" data-round="c" data-strip="off">
											
											<?php $yeteneklerim = get_field('yeteneklerim');?>
											
											<div class="arlo_tm_progress" data-value="<?php echo $yeteneklerim['yetenek_1_yuzdesi'];?>" data-color="#000">
												<span>
												<span class="label"><?php echo $yeteneklerim['yetenek_1_basligi'];?></span><span class="number"><?php echo $yeteneklerim['yetenek_1_yuzdesi'];?></span>
												</span>
												<div class="arlo_tm_bar_bg">
												<div class="arlo_tm_bar_wrap">
												<div class="arlo_tm_bar"></div>
												</div>
												</div>
											</div>
											
											<div class="arlo_tm_progress" data-value="<?php echo $yeteneklerim['yetenek_2_yuzdesi'];?>" data-color="#000">
												<span>
												<span class="label"><?php echo $yeteneklerim['yetenek_2_basligi'];?></span><span class="number"><?php echo $yeteneklerim['yetenek_2_yuzdesi'];?></span>
												</span>
												<div class="arlo_tm_bar_bg">
												<div class="arlo_tm_bar_wrap">
												<div class="arlo_tm_bar"></div>
												</div>
												</div>
											</div>
											
											<div class="arlo_tm_progress" data-value="<?php echo $yeteneklerim['yetenek_3_yuzdesi'];?>" data-color="#000">
												<span>
												<span class="label"><?php echo $yeteneklerim['yetenek_3_basligi'];?></span><span class="number"><?php echo $yeteneklerim['yetenek_3_yuzdesi'];?></span>
												</span>
												<div class="arlo_tm_bar_bg">
												<div class="arlo_tm_bar_wrap">
												<div class="arlo_tm_bar"></div>
												</div>
												</div>
											</div>
											
											
											<div class="arlo_tm_progress" data-value="<?php echo $yeteneklerim['yetenek_4_yuzdesi'];?>" data-color="#000">
												<span>
												<span class="label"><?php echo $yeteneklerim['yetenek_4_basligi'];?></span><span class="number"><?php echo $yeteneklerim['yetenek_4_yuzdesi'];?></span>
												</span>
												<div class="arlo_tm_bar_bg">
												<div class="arlo_tm_bar_wrap">
												<div class="arlo_tm_bar"></div>
												</div>
												</div>
											</div>
											
										</div>
									</div>
								</div>
								
								
								
							</div>
						</div>
					</div>
				</div>
				<!-- /SKILLS -->
				<?php endif;?>
				
				
				
				<?php $hizmetlerim_bolumunu_goster = get_field('hizmetlerim_bolumunu_goster');?>
				<?php if($hizmetlerim_bolumunu_goster):?>
				<!-- SERVICES -->
				<div class="arlo_tm_section" id="hizmetlerim">
					<div class="arlo_tm_services_wrap">
						<div class="container">
							<div class="arlo_tm_title_holder">
								<h3><?php the_field('hizmetlerim_baslik');?></h3>
								<span><?php the_field('hizmetlerim_yazi');?></span>
							</div>
							
							<div class="list_wrap">
								<ul>
									
								<?php $hizmetlerim = get_field('hizmetlerim');?>
								<?php if($hizmetlerim):?>
									
								<?php foreach($hizmetlerim as $hizmet_tek):
								$hizmet_icon = wp_get_attachment_image_src(get_post_thumbnail_id($hizmet_tek->ID),'thumbnail-full');
								$hizmet_baslik = get_the_title($hizmet_tek->ID);
								$hizmet_ozet = get_the_excerpt($hizmet_tek->ID);
								$hizmet_link = get_the_permalink($hizmet_tek->ID);
								?>
								<?php //echo "<pre>"; echo print_r($hizmet_link); echo "</pre>";?>
									
									
								<li>
									<div class="inner">
										<div class="icon">
											<img class="svg" src="<?php echo $hizmet_icon[0];?>" alt="camera-diaphragm" />
										</div>
										<div class="title_service">
											<h3><a href="<?php echo $hizmet_link;?>"><?php echo $hizmet_baslik;?></a></h3>
										</div>
										<div class="text">
											<p><?php echo $hizmet_ozet;?></p>
										</div>
									</div>

								</li>
								<?php endforeach;?>

								<?php endif;?>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- /SERVICES -->
				<?php endif;?>
				
				<?php $portfolyo_bolumunu_goster = get_field('portfolyo_bolumunu_goster');?>
				<?php if($portfolyo_bolumunu_goster):?>
				<!-- PORTFOLIO -->
				<div class="arlo_tm_section relative" id="portfolyo">
					<div class="arlo_tm_portfolio_wrapper_all">

						<!-- PORTFOLIO FILTER -->
						<div class="arlo_tm_second_portfolio">
						<div class="container">
							<div class="arlo_tm_portfolio_wrap">
								
								<div class="arlo_tm_title_holder portfolio">
									<h3><?php the_field('portfolyo_baslik');?></h3>
									<span><?php the_field('portfolyo_yazi');?></span>
								</div>
								
								<div class="arlo_tm_portfolio_titles"></div>
								<ul class="arlo_tm_portfolio_filter">
									<li><a href="#" class="current" data-filter="*">Tümü</a></li>
									<?php $portfolyo_kategoriler = get_terms([
									'taxonomy' => 'portfolyo-kategori',
									'hide_empty' => true,
									]);?>
									<?php foreach($portfolyo_kategoriler as $portfolyo_kategori):?>
									<?php //echo "<pre>"; echo print_r($portfolyo_kategori); echo "</pre>";?>
									<li><a href="#" data-filter=".<?php echo $portfolyo_kategori->slug;?>"><?php echo $portfolyo_kategori->name;?></a></li>
									<?php endforeach;?>
								</ul>
								
								
								<ul class="arlo_tm_portfolio_list gallery_zoom">
									
								<?php $portfolyo = get_field('portfolyo');?>
								<?php if($portfolyo):?>
									
								<?php foreach($portfolyo as $portfolyo_tek):
								$portfolyo_kapak = wp_get_attachment_image_src(get_post_thumbnail_id($portfolyo_tek->ID),'thumbnail-full');
								$portfolyo_baslik = get_the_title($portfolyo_tek->ID);
								$portfolyo_link = get_the_permalink($portfolyo_tek->ID);
								$portfolyo_kategori = get_the_terms($portfolyo_tek->ID, 'portfolyo-kategori');
								?>
								<?php // echo "<pre>"; echo print_r($portfolyo_kategori); echo "</pre>";?>
								<li class="<?php echo $portfolyo_kategori[0]->slug;?>">
									<div class="entry arlo_tm_portfolio_animation_wrap" data-title="<?php echo $portfolyo_baslik;?>" data-category="<?php echo $portfolyo_kategori[0]->name;?>">
										<a href="<?php echo $portfolyo_link;?>">
										<?php if($portfolyo_kapak):?>
										<img src="<?php echo get_template_directory_uri();?>/inc/img/portfolio/600x600.jpg" alt="600x600" />
										<div class="arlo_tm_portfolio_image_main" data-img-url="<?php echo $portfolyo_kapak[0];?>"></div>
										<?php endif;?>
										</a>
									</div>
								</li>	
								
								<?php endforeach;?>

								<?php endif;?>
									
									
									
								</ul>
							</div>
						</div>
					</div>
					<!-- /PORTFOLIO FILTER -->

					</div>
				</div>
				<!-- /PORTFOLIO -->
				<?php endif;?>

				<?php $referans_bolumunu_goster = get_field('referans_bolumunu_goster');?>
				<?php if($referans_bolumunu_goster):?>
				<!-- TESTIMONIALS -->
				<div class="arlo_tm_section" id="referanslar">
					<div class="arlo_tm_testimonials_wrapper_all">
						<div class="arlo_tm_universal_box_wrap">
							<div class="bg_wrap">
								<div class="overlay_image testimonial jarallax" data-speed="0"></div>
								<div class="overlay_color testimonial"></div>
							</div>
							<div class="content testimonial">
								<div class="arlo_tm_testimonial_wrap">
									<div class="container">
										<div class="carousel_wrap">
											<ul class="owl-carousel">
												
								<?php $referanslar = get_field('referanslar');?>
								<?php if($referanslar):?>

								<?php foreach($referanslar as $referans_tek):
								$referans_baslik = get_the_title($referans_tek->ID);
								//$referans_icerik = get_the_content($referans_tek->ID);
								?>
								<?php //echo "<pre>"; echo print_r($referans_tek); echo "</pre>";?>
								<li class="item">
									<div class="inner">
										<div class="quotebox_wrap">
											<i class="xcon-quote-left"></i>
										</div>
										<div class="definitions_wrap">
											<p><?php echo $referans_tek->post_content;?></p>
										</div>
										<div class="name_holder">
											<p><?php echo $referans_baslik;?>	</p>
										</div>
									</div>
								</li>				
								

								<?php endforeach;?>

								<?php endif;?>
												
												
												
												
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /TESTIMONIALS -->
				<?php endif;?>
				

				<?php $rakamlar_bolumunu_goster = get_field('rakamlar_bolumunu_goster');?>
				<?php if($rakamlar_bolumunu_goster):?>
				<!-- COUNTERBOX -->
				<div class="arlo_tm_section">
					<div class="container">
						<div class="arlo_tm_counter_wrap" data-col="4" data-delay="300">
							<ul class="arlo_tm_counter_list arlo_tm_miniboxes">
								
								<?php $rakamlar = get_field('rakamlar');?>
								
								<li>
									<div class="inner arlo_tm_minibox">
										<h3><span><span class="arlo_tm_counter" data-from="0" data-to="<?php echo $rakamlar['rakam_1_basligi'];?>" data-speed="3000">0</span></span></h3>
										<span><?php echo $rakamlar['rakam_1_aciklamasi'];?></span>
									</div>
								</li>
								<li>
									<div class="inner arlo_tm_minibox">
										<h3><span><span class="arlo_tm_counter" data-from="0" data-to="<?php echo $rakamlar['rakam_2_basligi'];?>" data-speed="3000">0</span></span></h3>
										<span><?php echo $rakamlar['rakam_2_aciklamasi'];?></span>
									</div>
								</li>
								<li>
									<div class="inner arlo_tm_minibox">
										<h3><span><span class="arlo_tm_counter" data-from="0" data-to="<?php echo $rakamlar['rakam_3_basligi'];?>" data-speed="3000">0</span></span></h3>
										<span><?php echo $rakamlar['rakam_3_aciklamasi'];?></span>
									</div>
								</li>
								<li>
									<div class="inner arlo_tm_minibox">
										<h3><span><span class="arlo_tm_counter" data-from="0" data-to="<?php echo $rakamlar['rakam_4_basligi'];?>" data-speed="3000">0</span></span></h3>
										<span><?php echo $rakamlar['rakam_4_aciklamasi'];?></span>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /COUNTERBOX -->
				<?php endif;?>


				
				<?php $haberler_bolumunu_goster = get_field('haberler_bolumunu_goster');?>
				<?php if($haberler_bolumunu_goster):?>
				<!-- NEWS -->
				<div class="arlo_tm_section" id="haberler">
					<div class="arlo_tm_news_wrap">
						<div class="container">
							<div class="arlo_tm_title_holder news">
								<h3><?php the_field('haberler_baslik');?></h3>
								<span><?php the_field('haberler_yazi');?></span>
							</div>
							<div class="arlo_tm_list_wrap blog_list">
								<ul class="total">
									
							<?php 
							$haberler_sayac = 0;		
							$haberler = new WP_Query(array(
							'post_type'      	=> 'post',
							'posts_per_page'	=> 3,
							)); ?>
							<?php while ( $haberler->have_posts() ) : $haberler->the_post(); 
									
							$haberler_kapak = wp_get_attachment_image_src( get_post_thumbnail_id($haberler->ID), 'thumbnail-full' );
							$haberler_tarih = get_the_date('d.m.Y');
							$haberler_kategori = get_the_category();
							?>
							
							<li class="wow fadeInUp" data-wow-duration="1.2s" data-wow-delay="
								<?php if($haberler_sayac==1):?>															  
								0.2s
								<?php elseif($haberler_sayac==2):?>
								0.4s
								<?php endif;?>															  
								">
								<div class="inner_list">
									<div class="image_wrap">
										<img class="small" src="<?php echo get_template_directory_uri();?>/inc/img/blog/500x350.jpg" alt="" />
										<img class="big" src="<?php echo get_template_directory_uri();?>/inc/img/blog/1170x450.jpg" alt="" />
										<div class="news_image" data-url="<?php echo $haberler_kapak[0];?>"></div>
										<a class="link_news" href="index.html"></a>
									</div>
									<div class="definitions_wrap">
										<div class="date_wrap">
									<p><?php echo $haberler_tarih;?> <a href="index.html"><?php echo $haberler_kategori[0]->name;?></a></p>
										</div>
										<div class="title_holder">
											<h3><a href="index.html"><?php the_title();?></a></h3>
										</div>
										<div class="definition">
											<p><?php the_excerpt();?></p>
										</div>
										<div class="full_def">
											<?php the_content();?>
										</div>

										<div class="read_more">
											<a href="#"><span>Devamını Oku</span></a>
										</div>
									</div>
								</div>
							</li>		
							<?php $haberler_sayac++; endwhile; ?>
							<?php wp_reset_postdata(); ?>
									
									

								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- /NEWS -->
				
				<?php endif;?>	

				<?php $iletisim_bolumunu_goster = get_field('iletisim_bolumunu_goster');?>
				<?php if($iletisim_bolumunu_goster):?>
				<!-- CONTACT & FOOTER -->
				<div class="arlo_tm_section" id="iletisim">
					<div class="container">
						<div class="arlo_tm_title_holder contact">
							<h3><?php the_field('iletisim_baslik');?></h3>
							<span><?php the_field('iletisim_yazi');?></span>
						</div>
					</div>
					<div class="arlo_tm_footer_contact_wrapper_all">
						<div class="arlo_tm_contact_wrap_all">
							<div class="container">
								<div class="leftbox">
									<div class="arlo_tm_mini_title_holder contact">
										<h4><?php the_field('iletisim_bilgiler_baslik');?></h4>
									</div>
									<div class="short_info_wrap">
										<ul>
											<li><p><label>Adres:</label><span><?php the_field('adres');?></span></p></li>
											<li><p><label>Email:</label><span><a href="mailto:<?php the_field('e-mail');?>"><?php the_field('e-mail');?></a></span></p></li>
											<li><p><label>Telefon:</label><span><a href="tel:<?php the_field('telefon');?>"><?php the_field('telefon');?></a></span></p></li>
									
										</ul>
									</div>
								</div>
								<div class="rightbox">
									<div class="arlo_tm_contact_wrap">
										<div class="main_input_wrap">
											
											<?php echo do_shortcode('[contact-form-7 id="194" title="İletişim formu 1"]');?>
											
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<!-- /CONTACT & FOOTER -->
	
				<?php endif;?>	



<?php get_footer(); ?>