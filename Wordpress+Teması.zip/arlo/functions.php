<?php 
function arlo_setup() {
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption') );
register_nav_menu( 'primary', __( 'Ana Menü', 'arlo' ) );
	
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 604, 270, true );

add_filter( 'use_default_gallery_style', '__return_false' );

}
add_action( 'after_setup_theme', 'arlo_setup' );

function arlo_scriptler_stiller() {
	
//Css Dosyaları	
wp_enqueue_style( 'plugins-css', get_template_directory_uri() . '/inc/css/plugins.css', array() );
wp_enqueue_style( 'style-css', get_template_directory_uri() . '/inc/css/style.css', array() );
wp_enqueue_style( 'arlo-style', get_stylesheet_uri(), array() );
  
//Js Dosyaları
wp_enqueue_script( 'jquery-js', get_template_directory_uri() . '/inc/js/jquery.js', array( 'jquery' ), '', true );	
wp_enqueue_script( 'plugins-js', get_template_directory_uri() . '/inc/js/plugins.js', array( 'jquery' ), '', true );	
wp_enqueue_script( 'init-js', get_template_directory_uri() . '/inc/js/init.js', array( 'jquery' ), '', true );
	
add_editor_style( array( 'css/editor-style.css', 'genericons/genericons.css' ) );
	
}

add_action( 'wp_enqueue_scripts', 'arlo_scriptler_stiller' );

//Gutenberg Devre Dışı
add_filter('use_block_editor_for_post', '__return_false', 10);
add_filter('use_block_editor_for_post_type', '__return_false', 10);
add_filter('use_widgets_block_editor', '__return_false');

//İçerik Tipleri
function icerik_tipleri() {

	$labels = array(
		'name'                => __( 'Hizmetlerim' ),
		'singular_name'       => __( 'Hizmetlerim'),
		'menu_name'           => __( 'Hizmetlerim' ),
		'parent_item_colon'   => __( 'Hizmetlerim' ),
		'all_items'           => __( 'Tüm Hizmetlerim' ),
		'view_item'           => __( 'Hizmetlerimi Gör' ),
		'add_new_item'        => __( 'Yeni Hizmet Ekle' ),
		'add_new'             => __( 'Yeni Hizmet Ekle' ),
		'edit_item'           => __( 'Hizmet Düzenle' ),
		'update_item'         => __( 'Hizmet Güncelle' ),
		'search_items'        => __( 'Hizmet Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	$args = array(
		'label'               => __( 'hizmet' ),
		'description'         => __( 'Hizmet' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'thumbnail','comments','excerpt' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest' 		  => true,
		'rest_base'          => 'at',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		"menu_icon" => "dashicons-welcome-learn-more",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'hizmet', $args );
   
	$labels = array(
		'name'                => __( 'Portfolyo' ),
		'singular_name'       => __( 'Portfolyo'),
		'menu_name'           => __( 'Portfolyo' ),
		'parent_item_colon'   => __( 'Portfolyo' ),
		'all_items'           => __( 'Tüm Portfolyo' ),
		'view_item'           => __( 'Portfolyo Gör' ),
		'add_new_item'        => __( 'Yeni Portfolyo Ekle' ),
		'add_new'             => __( 'Yeni Portfolyo Ekle' ),
		'edit_item'           => __( 'Portfolyo Düzenle' ),
		'update_item'         => __( 'Portfolyo Güncelle' ),
		'search_items'        => __( 'Portfolyo Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	$args = array(
		'label'               => __( 'portfolyo' ),
		'description'         => __( 'Portfolyo' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'thumbnail','comments','excerpt' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest' 		  => true,
		'rest_base'          => 'at',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		"menu_icon" => "dashicons-admin-customizer",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'portfolyo', $args );	
	
	
	$labels = array(
		'name'                => __( 'Referanslar' ),
		'singular_name'       => __( 'Referanslar'),
		'menu_name'           => __( 'Referanslar' ),
		'parent_item_colon'   => __( 'Referanslar' ),
		'all_items'           => __( 'Tüm Referanslar' ),
		'view_item'           => __( 'Referans Gör' ),
		'add_new_item'        => __( 'Yeni Referans Ekle' ),
		'add_new'             => __( 'Yeni Referans Ekle' ),
		'edit_item'           => __( 'Referans Düzenle' ),
		'update_item'         => __( 'Referans Güncelle' ),
		'search_items'        => __( 'Referans Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	$args = array(
		'label'               => __( 'referans' ),
		'description'         => __( 'Referans' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'thumbnail','comments','excerpt' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest' 		  => true,
		'rest_base'          => 'at',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		"menu_icon" => "dashicons-admin-users",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'referans', $args );
	
}

add_action( 'init', 'icerik_tipleri', 0 );

//İçerik Tipi Kategorileri/
function taksonomiler() {
	
$labels = array(
"name" => __( 'Portfolyo Kategori', '' ),
"singular_name" => __( 'Portfolyo Kategori', '' ),
"menu_name" => __( 'Portfolyo Kategori', '' ),
"all_items" => __( 'Tüm Portfolyo Kategorileri', '' ),
"edit_item" => __( 'Portfolyo Kategorisi Düzenle', '' ),
"view_item" => __( 'Portfolyo Kategorisi Gör', '' ),
"update_item" => __( 'Portfolyo Kategorisi Güncelle', '' ),
"add_new_item" => __( 'Yeni Portfolyo Kategorisi Ekle', '' ),
"new_item_name" => __( 'Yeni Portfolyo Kategorisi Ekle', '' ),	
);

$args = array(
"label" => __( 'Portfolyo Kategori', '' ),
"labels" => $labels,
"public" => true,
"hierarchical" => true,
"label" => "Portfolyo Kategori",
"show_ui" => true,
"query_var" => true,
"rewrite" => array( 'slug' => 'portfolyo-kategori', 'with_front' => true, 'hierarchical' => true ),
"show_admin_column" => true,
"show_in_rest" => true,
"rest_base" => "",
"show_in_quick_edit" => true,
);
register_taxonomy( "portfolyo-kategori", array( "portfolyo" ), $args );
	
	
	

}
add_action( 'init', 'taksonomiler' );

//SVG Yükleme İzni
function add_file_types_to_uploads($file_types){
$new_filetypes = array();
$new_filetypes['svg'] = 'image/svg+xml';
$file_types = array_merge($file_types, $new_filetypes );
return $file_types;
}
add_action('upload_mimes', 'add_file_types_to_uploads');


//Panel Özelleştirmeleri
add_action('admin_head', 'admin_style');
function admin_style() {
include ("style-admin.php"); 
} 

add_filter('admin_title', 'my_admin_title', 10, 2);
function my_admin_title($admin_title, $title)
{
    return get_bloginfo('name').' &bull; '.$title;
}

function login_style() { 
include ("style-login.php"); 
}
add_action( 'login_enqueue_scripts', 'login_style' );


function login_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'login_url' );


function login_url_title() {
    return get_bloginfo('name').' - Yönetim Paneli';
}
add_filter( 'login_headertext', 'login_url_title' );



//Favicon
function add_favicon() {
	echo '<link rel="shortcut icon" href="'.get_template_directory_uri().'/inc/img/logo/favicon.png" type="image/x-icon"/>';	
}

add_action('login_head', 'add_favicon');
add_action('admin_head', 'add_favicon');
add_action('wp_head', 'add_favicon');











