<?php get_header();?>

<div class="arlo_tm_portfolio_single_wrap">
<div class="container">
	<div class="title_holder">
		<h3><?php the_title();?></h3>
	</div>
	<div class="details_wrap">
		<div class="leftbox">
			<div class="name_holder">
				<h3>Proje Detayları</h3>
			</div>
			<div class="short_list">
				<ul>
					<li>
						<span class="first">Kategori :</span>
						<span class="second">
						<?php $portfolyo_kategori = get_the_terms($post->ID, 'portfolyo-kategori');?>
						<?php echo $portfolyo_kategori[0]->name;?>
						</span>
					</li>
					<?php $musteri = get_field('musteri');?>
					<?php if($musteri):?>
					<li>
						<span class="first">Müşteri :</span>
						<span class="second"><?php echo $musteri;?></span>
					</li>
					<?php endif;?>
					
					<?php $tarih = get_field('tarih');?>
					<?php if($tarih):?>
					<li>
						<span class="first">Tarih :</span>
						<span class="second"><?php echo $tarih;?></span>
					</li>
					<?php endif;?>
				</ul>
			</div>
		</div>
		<div class="rightbox">
			<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content();?>	
			<?php endwhile;?>
		</div>	
		
	</div>

	<div class="pagination_wrap">
		<div class="prev">
			<?php previous_post_link();?>
		</div>
		<div class="next">
			<?php next_post_link();?>
		</div>
	</div>
</div>
</div>

<?php get_footer(); ?>