<?php get_header();?>

<div class="arlo_tm_portfolio_single_wrap">
<div class="container">
	<div class="title_holder">
		<h3><?php the_title();?></h3>
	</div>
	<div class="details_wrap">

		<div class="full_def">
			<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content();?>	
			<?php endwhile;?>
		</div>
	</div>

	<div class="pagination_wrap">
		<div class="prev">
			<?php previous_post_link();?>
		</div>
		<div class="next">
			<?php next_post_link();?>
		</div>
	</div>
</div>
</div>

<?php get_footer(); ?>