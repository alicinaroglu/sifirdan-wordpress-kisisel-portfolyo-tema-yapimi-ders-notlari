<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="generator" content="<?php echo esc_url( home_url( '/' ) ); ?>"/>    
<meta name="copyright" content="Copyright (c) <?php echo date('Y'); ?> Her Hakkı Saklıdır">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php include('style.php');?>
<?php wp_head(); ?>
</head>
<body <?php body_class( '' ); ?>>

	
	
<!-- WRAPPER ALL -->
<div class="arlo_tm_wrapper_all">

	<div id="arlo_tm_popup_blog">
		<div class="container">
			<div class="inner_popup scrollable"></div>
		</div>
		<span class="close"><a href="#"></a></span>
	</div>
	
	<!-- PRELOADER -->
	<div class="arlo_tm_preloader">
		<div class="spinner_wrap">
			<div class="spinner"></div>
		</div>
	</div>
	<!-- /PRELOADER -->
	
	<!-- MOBILE MENU -->
	<div class="arlo_tm_mobile_header_wrap">
		<div class="main_wrap">
			<div class="logo">
				<a href="index.html"><img src="<?php echo get_template_directory_uri();?>/inc/img/logo/mobile_logo.png" alt="mobile_logo" /></a>
			</div>
			<div class="arlo_tm_trigger">
				<div class="hamburger hamburger--collapse-r">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="arlo_tm_mobile_menu_wrap">
   			<div class="mob_menu">
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container'=> false, 'menu_class' => 'anchor_nav', 'menu_id' => '') ); ?>
			</div>
		</div>
	</div>
	<!-- /MOBILE MENU -->
	
    <!-- CONTENT -->
	<div class="arlo_tm_content">
		
		<!-- LEFTPART -->
		<div class="arlo_tm_leftpart_wrap">
			<div class="leftpart_inner">
				<div class="logo_wrap">
					<a href="#"><img src="<?php echo get_template_directory_uri();?>/inc/img/logo/desktop-logo.png" alt="desktop-logo" /></a>
				</div>
				<div class="menu_list_wrap">
					<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container'=> false, 'menu_class' => 'anchor_nav', 'menu_id' => '') ); ?>
				</div>
				<div class="leftpart_bottom">
					<div class="social_wrap">
						<ul>
							<li><a href="#"><i class="xcon-youtube-play"></i></a></li>
							<li><a href="#"><i class="xcon-facebook"></i></a></li>
							<li><a href="#"><i class="xcon-twitter"></i></a></li>
							<li><a href="#"><i class="xcon-linkedin"></i></a></li>
							<li><a href="#"><i class="xcon-instagram"></i></a></li>
							
						</ul>
					</div>
				</div>
				<a class="arlo_tm_resize" href="#"><i class="xcon-angle-left"></i></a>
			</div>
		</div>
		<!-- /LEFTPART -->
		
		<!-- RIGHTPART -->
		<div class="arlo_tm_rightpart">
			<div class="rightpart_inner">
		
		
		
		